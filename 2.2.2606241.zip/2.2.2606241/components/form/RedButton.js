(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/form/RedButton"],{"48cf":function(t,n,e){"use strict";e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return a})),e.d(n,"a",(function(){}));var u=function(){var t=this.$createElement;this._self._c},a=[]},4962:function(t,n,e){"use strict";e.r(n);var u=e("6326"),a=e.n(u);for(var r in u)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(r);n["default"]=a.a},"4dfe":function(t,n,e){},6326:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"RedButton",props:{text:{type:String,default:""}},data:function(){return{}}};n.default=u},"740a":function(t,n,e){"use strict";e.r(n);var u=e("48cf"),a=e("4962");for(var r in a)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(r);e("ab82");var f=e("828b"),o=Object(f["a"])(a["default"],u["b"],u["c"],!1,null,"2d8452a4",null,!1,u["a"],void 0);n["default"]=o.exports},ab82:function(t,n,e){"use strict";var u=e("4dfe"),a=e.n(u);a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/form/RedButton-create-component',
    {
        'components/form/RedButton-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("740a"))
        })
    },
    [['components/form/RedButton-create-component']]
]);
