(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/form/FormSwitchItem"],{"21ba":function(t,e,n){"use strict";var u=n("e452"),i=n.n(u);i.a},8885:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"FormSwitchItem",props:{value:{type:[String,Number,Boolean],default:""},label:{type:String,default:""},required:{type:Boolean,default:!1}},data:function(){return{}},methods:{handleChange:function(t){this.$emit("input",t?1:0)},handleBlur:function(t){this.$emit("blur",t?1:0)}}};e.default=u},b8d0:function(t,e,n){"use strict";n.r(e);var u=n("e309"),i=n("fbe6");for(var r in i)["default"].indexOf(r)<0&&function(t){n.d(e,t,(function(){return i[t]}))}(r);n("21ba");var o=n("828b"),a=Object(o["a"])(i["default"],u["b"],u["c"],!1,null,"1bd864f0",null,!1,u["a"],void 0);e["default"]=a.exports},e309:function(t,e,n){"use strict";n.d(e,"b",(function(){return i})),n.d(e,"c",(function(){return r})),n.d(e,"a",(function(){return u}));var u={uSwitch:function(){return Promise.all([n.e("common/vendor"),n.e("uni_modules/uview-ui/components/u-switch/u-switch")]).then(n.bind(null,"dd1c"))}},i=function(){var t=this.$createElement;this._self._c},r=[]},e452:function(t,e,n){},fbe6:function(t,e,n){"use strict";n.r(e);var u=n("8885"),i=n.n(u);for(var r in u)["default"].indexOf(r)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(r);e["default"]=i.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/form/FormSwitchItem-create-component',
    {
        'components/form/FormSwitchItem-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("b8d0"))
        })
    },
    [['components/form/FormSwitchItem-create-component']]
]);
