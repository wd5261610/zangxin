(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/lottery/components/withdraw"],{1043:function(t,n,e){},"4c23":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"LotteryWithdraw",props:{amount:{type:[Number,String],default:"0.3"},type:{type:String,default:"alipay"}},computed:{confirmText:function(){return 1==this.type?"确认收款":"开心收下"},tipText:function(){return 1==this.type?"已发放，请确认":"已发放，请查收"},withdrawType:function(){return 1==this.type?"微信提现":"余额提现"}},methods:{handleConfirm:function(){this.$emit("confirm")}}};n.default=r},"6e82":function(t,n,e){"use strict";e.r(n);var r=e("edcd"),i=e("f28a");for(var u in i)["default"].indexOf(u)<0&&function(t){e.d(n,t,(function(){return i[t]}))}(u);e("86f7");var o=e("828b"),a=Object(o["a"])(i["default"],r["b"],r["c"],!1,null,"aea41798",null,!1,r["a"],void 0);n["default"]=a.exports},"86f7":function(t,n,e){"use strict";var r=e("1043"),i=e.n(r);i.a},edcd:function(t,n,e){"use strict";e.d(n,"b",(function(){return r})),e.d(n,"c",(function(){return i})),e.d(n,"a",(function(){}));var r=function(){var t=this.$createElement;this._self._c},i=[]},f28a:function(t,n,e){"use strict";e.r(n);var r=e("4c23"),i=e.n(r);for(var u in r)["default"].indexOf(u)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(u);n["default"]=i.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/lottery/components/withdraw-create-component',
    {
        'components/lottery/components/withdraw-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("6e82"))
        })
    },
    [['components/lottery/components/withdraw-create-component']]
]);
