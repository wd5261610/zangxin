(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/lottery/components/start"],{2229:function(t,n,e){},"63ca":function(t,n,e){"use strict";e.r(n);var u=e("d69a"),o=e.n(u);for(var i in u)["default"].indexOf(i)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(i);n["default"]=o.a},"70d2":function(t,n,e){"use strict";e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return o})),e.d(n,"a",(function(){}));var u=function(){var t=this.$createElement;this._self._c},o=[]},c3d6:function(t,n,e){"use strict";e.r(n);var u=e("70d2"),o=e("63ca");for(var i in o)["default"].indexOf(i)<0&&function(t){e.d(n,t,(function(){return o[t]}))}(i);e("ecbd");var c=e("828b"),r=Object(c["a"])(o["default"],u["b"],u["c"],!1,null,"519ac2ce",null,!1,u["a"],void 0);n["default"]=r.exports},d69a:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"LotteryStart",props:{maxAmount:{type:[Number,String],default:30}},data:function(){return{isBouncing:!1,bounceTimer:null}},mounted:function(){this.startBounce()},beforeDestroy:function(){this.stopBounce()},methods:{startBounce:function(){var t=this;this.bounceTimer=setInterval((function(){t.isBouncing=!0,setTimeout((function(){t.isBouncing=!1}),500)}),2e3)},stopBounce:function(){this.bounceTimer&&(clearInterval(this.bounceTimer),this.bounceTimer=null)},handleStart:function(){this.stopBounce(),this.$emit("start")},handleViewRecord:function(){this.$util.jump({url:"/plugin/cashlottery/log"})}}};n.default=u},ecbd:function(t,n,e){"use strict";var u=e("2229"),o=e.n(u);o.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/lottery/components/start-create-component',
    {
        'components/lottery/components/start-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("c3d6"))
        })
    },
    [['components/lottery/components/start-create-component']]
]);
