(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/diy/mpBannerAd/mpBannerAd"],{"164f":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={name:"blank",props:{options:{type:Object,default:function(){return{name:"mpBannerAd",data:{unitId:"",adType:"banner"},style:{}}}}},data:function(){return{}},methods:{jump:function(n){this.$util.jump(n)}}};t.default=u},"706e":function(n,t,e){"use strict";e.r(t);var u=e("afc6"),a=e("8606");for(var r in a)["default"].indexOf(r)<0&&function(n){e.d(t,n,(function(){return a[n]}))}(r);var f=e("828b"),i=Object(f["a"])(a["default"],u["b"],u["c"],!1,null,null,null,!1,u["a"],void 0);t["default"]=i.exports},8606:function(n,t,e){"use strict";e.r(t);var u=e("164f"),a=e.n(u);for(var r in u)["default"].indexOf(r)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(r);t["default"]=a.a},afc6:function(n,t,e){"use strict";e.d(t,"b",(function(){return u})),e.d(t,"c",(function(){return a})),e.d(t,"a",(function(){}));var u=function(){var n=this.$createElement;this._self._c},a=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/diy/mpBannerAd/mpBannerAd-create-component',
    {
        'components/diy/mpBannerAd/mpBannerAd-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("706e"))
        })
    },
    [['components/diy/mpBannerAd/mpBannerAd-create-component']]
]);
