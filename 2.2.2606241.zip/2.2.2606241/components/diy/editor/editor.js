(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/diy/editor/editor"],{"140e":function(n,t,e){"use strict";e.r(t);var r=e("a599"),u=e.n(r);for(var o in r)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return r[n]}))}(o);t["default"]=u.a},"36c6":function(n,t,e){"use strict";e.d(t,"b",(function(){return u})),e.d(t,"c",(function(){return o})),e.d(t,"a",(function(){return r}));var r={uParse:function(){return Promise.all([e.e("common/vendor"),e.e("uni_modules/uview-ui/components/u-parse/u-parse")]).then(e.bind(null,"90c0"))}},u=function(){var n=this.$createElement;this._self._c},o=[]},a599:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={props:{options:{type:Object,default:function(){return{name:"editor",data:{nodes:""},style:{pdt:0,pdb:0,pdlr:0,bgColor:"#fff",mgt:0,mglr:0}}}}},name:"editor",data:function(){return{}},watch:{}};t.default=r},fdf2:function(n,t,e){"use strict";e.r(t);var r=e("36c6"),u=e("140e");for(var o in u)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(o);var a=e("828b"),i=Object(a["a"])(u["default"],r["b"],r["c"],!1,null,null,null,!1,r["a"],void 0);t["default"]=i.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/diy/editor/editor-create-component',
    {
        'components/diy/editor/editor-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("fdf2"))
        })
    },
    [['components/diy/editor/editor-create-component']]
]);
