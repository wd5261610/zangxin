var siteinfo = {
	"uniacid": "1",
	"version": "2.2.2606241",
	"siteroot": "https://zangxinkeji.com"
};
module.exports = siteinfo;   
        