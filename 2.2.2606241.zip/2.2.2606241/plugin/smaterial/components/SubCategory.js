require('../../common/vendor.js');(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugin/smaterial/components/SubCategory"],{6013:function(t,n,e){"use strict";e.r(n);var u=e("b4fb"),i=e.n(u);for(var r in u)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(r);n["default"]=i.a},"9bf7":function(t,n,e){"use strict";e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return i})),e.d(n,"a",(function(){}));var u=function(){var t=this.$createElement;this._self._c},i=[]},b4fb:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"SubCategory",props:{list:{type:Array,default:function(){return[]}}},methods:{jump:function(t){this.$util.jump("/plugin/smaterial/list?category_id="+t.id)}}};n.default=u},c633:function(t,n,e){"use strict";e.r(n);var u=e("9bf7"),i=e("6013");for(var r in i)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return i[t]}))}(r);e("d2b7");var a=e("828b"),f=Object(a["a"])(i["default"],u["b"],u["c"],!1,null,"7b84f342",null,!1,u["a"],void 0);n["default"]=f.exports},d2b7:function(t,n,e){"use strict";var u=e("fee2"),i=e.n(u);i.a},fee2:function(t,n,e){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugin/smaterial/components/SubCategory-create-component',
    {
        'plugin/smaterial/components/SubCategory-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("c633"))
        })
    },
    [['plugin/smaterial/components/SubCategory-create-component']]
]);
