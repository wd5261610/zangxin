require('../../common/vendor.js');(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugin/short_video/components/OriginPrice"],{"0d21":function(t,n,e){"use strict";e.r(n);var i=e("36bd"),r=e.n(i);for(var u in i)["default"].indexOf(u)<0&&function(t){e.d(n,t,(function(){return i[t]}))}(u);n["default"]=r.a},"34a0":function(t,n,e){"use strict";e.d(n,"b",(function(){return i})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){}));var i=function(){var t=this.$createElement,n=(this._self._c,Number(this.price).toFixed(2));this.$mp.data=Object.assign({},{$root:{g0:n}})},r=[]},"36bd":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var i={name:"VipPrice",props:{price:{type:[Number,String],default:""},vip_price:{type:[Number,String],default:""},fontSize:{type:[Number,String],default:"24rpx"}},mounted:function(){}};n.default=i},7042:function(t,n,e){},"7d07":function(t,n,e){"use strict";var i=e("7042"),r=e.n(i);r.a},"985a":function(t,n,e){"use strict";e.r(n);var i=e("34a0"),r=e("0d21");for(var u in r)["default"].indexOf(u)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(u);e("7d07");var a=e("828b"),o=Object(a["a"])(r["default"],i["b"],i["c"],!1,null,"39318627",null,!1,i["a"],void 0);n["default"]=o.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugin/short_video/components/OriginPrice-create-component',
    {
        'plugin/short_video/components/OriginPrice-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("985a"))
        })
    },
    [['plugin/short_video/components/OriginPrice-create-component']]
]);
