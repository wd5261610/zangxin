require('../../common/vendor.js');(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugin/short_video/components/PriceTag"],{9416:function(n,t,e){"use strict";var u=e("9cb2"),f=e.n(u);f.a},"9cb2":function(n,t,e){},d068:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={name:"VipPrice",props:{price:{type:[Number,String],default:""},fontSize:{type:[Number,String],default:"24rpx"}},mounted:function(){}};t.default=u},db2e:function(n,t,e){"use strict";e.r(t);var u=e("ff6a"),f=e("ff08");for(var r in f)["default"].indexOf(r)<0&&function(n){e.d(t,n,(function(){return f[n]}))}(r);e("9416");var i=e("828b"),c=Object(i["a"])(f["default"],u["b"],u["c"],!1,null,"abf8bc10",null,!1,u["a"],void 0);t["default"]=c.exports},ff08:function(n,t,e){"use strict";e.r(t);var u=e("d068"),f=e.n(u);for(var r in u)["default"].indexOf(r)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(r);t["default"]=f.a},ff6a:function(n,t,e){"use strict";e.d(t,"b",(function(){return u})),e.d(t,"c",(function(){return f})),e.d(t,"a",(function(){}));var u=function(){var n=this.$createElement;this._self._c},f=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugin/short_video/components/PriceTag-create-component',
    {
        'plugin/short_video/components/PriceTag-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("db2e"))
        })
    },
    [['plugin/short_video/components/PriceTag-create-component']]
]);
