require('../../common/vendor.js');(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugin/bargain/public/detailInfos"],{9767:function(t,n,e){"use strict";e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return i})),e.d(n,"a",(function(){}));var u=function(){var t=this.$createElement,n=(this._self._c,this.list&&this.list.length>0);this.$mp.data=Object.assign({},{$root:{g0:n}})},i=[]},b826:function(t,n,e){"use strict";e.r(n);var u=e("9767"),i=e("e856");for(var r in i)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return i[t]}))}(r);e("eb41");var a=e("828b"),c=Object(a["a"])(i["default"],u["b"],u["c"],!1,null,"0be69ff2",null,!1,u["a"],void 0);n["default"]=c.exports},bccc:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={props:{fontSizeAdjust:{type:Number,default:0},list:{type:Array,default:function(){return[]}}}};n.default=u},e203:function(t,n,e){},e856:function(t,n,e){"use strict";e.r(n);var u=e("bccc"),i=e.n(u);for(var r in u)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(r);n["default"]=i.a},eb41:function(t,n,e){"use strict";var u=e("e203"),i=e.n(u);i.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugin/bargain/public/detailInfos-create-component',
    {
        'plugin/bargain/public/detailInfos-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("b826"))
        })
    },
    [['plugin/bargain/public/detailInfos-create-component']]
]);
